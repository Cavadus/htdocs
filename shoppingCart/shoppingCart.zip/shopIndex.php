<html>
  <head>
    <title>Shopping Cart</title>
  </head>

  <body>
    <br />
    <br />

    <table width="324" border="0" align="center">

      <tr>
        <td width="150" height="90"><img src="bubbles.jpg" width="150" height="100"></td>
        <td width="9">&nbsp;</td>
        <td width="150"><img src="beach.jpg" width="150" height="100"</td>
      </tr>

      <tr>
        <td height="24" align="center"><br>
          <a href="shopOrder.php?add=Bubbles Theme&price=15.00&qty=1">Bubbles Theme</a>&nbsp;
          <br />$15.00</td>
          <td>&nbsp;</td>
          <td align="center"><a href="shopOrder.php?add=Beach&price=10.00&qty=1">Tropical Beach</a>&nbsp;
            <br/>$10.00</td>
      </tr>

    </table><br /><br />
    <center><a href="shopOrder.php">View Cart</a></center>

  </body>

</html>
